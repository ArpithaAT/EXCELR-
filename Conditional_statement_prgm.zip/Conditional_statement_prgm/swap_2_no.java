package Conditional_statement_prgm;

import java.util.Scanner;

public class swap_2_no {

	public static void main(String[] args) {
	var a=10;
	var b=20;
	
	
	
	a=a+b;
	b=a-b;
	a=a-b;
	
System.out.println(a);
System.out.println(b);

	}

}
