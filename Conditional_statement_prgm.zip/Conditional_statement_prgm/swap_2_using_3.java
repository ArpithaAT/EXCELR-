package Conditional_statement_prgm;

public class swap_2_using_3 {

	public static void main(String[] args) {
		var a=20;
		var b=10;
		int c;
		
c=a;
a=b;
b=c;
		
	System.out.println(a);
	System.out.println(b);

		}

}



