package Conditional_statement_prgm;

import java.util.Scanner;

public class vowel_cons {

	public static void main(String[] args) {
	
char ch='i';


if(ch=='a'|| ch=='e'|| ch=='i' || ch=='o' || ch=='u')
{
	System.out.println("vowel");
}
else
{
	System.out.println("consonant");
}


}

}
